//var server = require("./server");
// var router = require("./router");
// server.start(router.route);
// // 输出全局变量 __filename 的值
// // __filename 表示当前正在执行的脚本的文件名。它将输出文件所在位置的绝对路径，且和命令行参数所指定的文件名不一定相同。
// // 如果在模块中，返回的值是模块文件的路径。
// console.log( __filename );
// // 输出全局变量 __dirname 的值 
// // __dirname 表示当前执行脚本所在的目录。
// console.log( __dirname );
// // 平台信息
// console.log(process.platform);
var google = require("./google")
var fs = require('fs');
var http = require('http');
var https = require("https");
/**要翻译的目录/文件 默认当前解压文件夹 */
var filePath = __dirname//'E:\\策划\\resource\\eui_skins\\Rebirth\\Rebirth';
var logPath = __dirname + '\\chinese.log';
var map = {};
var num = 0;
var dictionary = (function () {
    var map = {};
    return {
        logPath: __dirname + '\\chinese.log',
        set: function (key, val) {
            map[key] = val || '';
        },
        get: function (key) {
            return map[key] || key;
        },
        save2File: function (callback) {
            fs.writeFile(this.logPath, JSON.stringify(map).replace(/","/g, '",\r\n"'), { encoding: 'utf8', flag: 'w' }, function (err) {
                if (err) throw err;
                if (!err && callback) {
                    callback();
                }
            });
        },
        loadFile: function (callback) {
            fs.readFile(this.logPath, { encoding: 'utf8' }, function (err, data) {
                map = JSON.parse(data);
                callback();
            })
        },
        translateByGoogle: function (callback) {
            var index = 0;
            for (var key in map) {
                if (map[key] == '') {
                    index++;
                    (function (key) {
                        let tl = "en";//要翻译的语言
                        let hl = "zh-CN";//当前语言
                        let tk = google.token(key);
                        /**ie=UTF-8&oe=UTF-8 不添加这个到url里返回的数据是乱码的 */
                        let googlehttp = "https://translate.google.cn/translate_a/single?client=webapp&sl=auto&ie=UTF-8&oe=UTF-8&tl=" + tl + "&hl=" + hl + "&dt=at&dt=bd&dt=ex&dt=ld&dt=md&dt=qca&dt=rw&dt=rm&dt=ss&dt=t&dt=gt&ssel=0&tsel=0&kc=1&tk=" + tk + "&q=" + encodeURI(key);
                        //console.log(googlehttp);
                        let httpPath = "http://translate.google.cn/translate_a/t?client=t&hl=zh-CN&sl=zh-CN&tl=en&ie=UTF-8&oe=UTF-8&oc=2&otf=1&ssel=3&tsel=6&sc=2&q=" + encodeURI(key);
                        https.get(googlehttp, function (res) {
                            const { statusCode } = res;
                            // console.log(`HEADERS: ${JSON.stringify(res.headers)}`)
                            const contentType = res.headers['content-type'];
                            let error;
                            if (statusCode !== 200) {
                                error = new Error('请求失败\n' + `状态码: ${statusCode}`);
                            }
                            else if (!/^application\/json/.test(contentType)) {
                                error = new Error('无效的 content-type.\n' + `期望的是 application/json 但接收到的是 ${contentType}`);
                            }
                            if (error) {
                                console.error(error.message);
                                /* 消费响应数据来释放内存。*/
                                res.resume(); return;
                            }
                            res.setEncoding('utf8');
                            let rawData = ''; res.on('data', (chunk) => {
                                // let buff = new Buffer(chunk)
                                // rawData += buff.toString("utf8");
                                rawData += chunk;
                            });
                            res.on('end', () => {
                                try {
                                    const parsedData = JSON.parse(rawData);
                                    map[key] = parsedData[0][0][0];
                                    index--;
                                    if (index == 0) {
                                        callback();
                                    }
                                } catch (e) {
                                    console.error(e.message);
                                }
                            });
                        }).on('error', function (e) {
                            console.log('http error');
                            index--;
                            if (index == 0) {
                                callback();
                            }
                            console.log("Got error: " + e.message);
                        });
                        //     res.setEncoding('utf8');
                        //     var body = "";
                        //     res.on('data', function (chunk) {
                        //         body += chunk;
                        //     }).on('end', function () {
                        //         console.log(body)
                        //         var obj = eval('(' + body + ')');
                        //         map[key] = obj[0][0][0];
                        //         index--;
                        //         if (index == 0) {
                        //             callback();
                        //         }
                        //     });
                        // }
                        // ).on('error', function (e) {
                        //     console.log('http error');
                        //     index--;
                        //     if (index == 0) {
                        //         callback();
                        //     }
                        //     console.log("Got error: " + e.message);
                        // });

                    })(key);
                }
            }
        }
    }
})();


function File() {
    var index = 0;
    var _readFile = function (pathStr, fileBack, doneBack) {
        fs.readFile(pathStr, { encoding: 'utf8' }, function (err, data) {
            index--;
            if (err) {
                data = "";
                console.log(err, pathStr)
                //throw err;
            }
            fileBack(data, pathStr);
            if (index == 0) {
                doneBack();
            }
        });
    };
    var _walkDir = function (pathStr, fileBack, doneBack) {
        fs.readdir(pathStr, function (err, files) {
            files.forEach(function (file) {
                if (fs.statSync(pathStr + '/' + file).isDirectory()) {
                    _walkDir(pathStr + '/' + file, fileBack, doneBack);
                } else {
                    if (/.html$|.exml$/.test(file)) {//只解析.html和.exml类型的文件
                        index++;
                        _readFile(pathStr + '/' + file, fileBack, doneBack);
                    }
                    return;
                }
            });
        });
    }
    this.walkDir = function (pathStr, fileBack, doneBack) {
        index = 0;
        _walkDir(pathStr, fileBack, doneBack);
    }
}

//第一步  获取中文
dictionary.logPath = logPath;

new File().walkDir(filePath, function (data) {
    if (!!data) {
        slice(data)
        // var match = data.match(/[\u4e00-\u9faf]+/g);
        // if (!!match) {
        //     match.forEach(function (mat) {
        //         dictionary.set(mat);
        //     })
        // }
    }
}, function () {
    console.log('获取中文 OK');
    dictionary.save2File(function () {
        console.log('开始翻译');
        dictionary.loadFile(function () {
            dictionary.translateByGoogle(function () {
                dictionary.save2File(function () {
                    dictionary.loadFile(function () {
                        new File().walkDir(filePath, function (data, pathStr) {
                            if (/.exml$/.test(pathStr)) {//判断是不是.exml类型的文件 进行替换中文
                                fs.writeFile(pathStr, data.replace(/(?<=").*?(?=")/g, function (ch) {
                                    return dictionary.get(ch);
                                }), { encoding: 'ascii', flag: 'w' }, function (err) {
                                    if (err) throw err;
                                });
                            }

                        }, function () {
                            console.log('中文替换 OK');
                        })
                    });
                });
            })
        });
    });

})
function slice(data) {
    // let match = data.match(/="\S*"/g);
    let match = data.match(/(?<=").*?(?=")/g);
    if (!!match) {
        match.forEach(function (mat) {
            let matchChinese = mat.match(/[\u4e00-\u9faf]+/g)
            if (!!matchChinese) {
                //console.log(mat);
                dictionary.set(mat);
            }
        })
    }
}

//第二步  google翻译

// dictionary.loadFile(function () {
//     dictionary.translateByGoogle(function () {
//         dictionary.save2File();
//     })
// });

// //第三步 中文替换

// dictionary.loadFile(function () {
//     new File().walkDir(filePath, function (data, pathStr) {
//         fs.writeFile(pathStr, data.replace(/[\u4e00-\u9faf]+/g, function (ch) {
//             return dictionary.get(ch);
//         }), { encoding: 'ascii', flag: 'w' }, function (err) {
//             if (err) throw err;
//         });
//     }, function () {
//         console.log('中文替换 OK');
//     })
// });



